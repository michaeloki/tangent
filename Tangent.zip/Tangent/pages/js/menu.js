/*
  var app = angular.module('myUser', []);
   app.controller('myDetails', function ($scope) {
	   $scope.RealName = "Michael"; 
	    });*/
		
		var app = angular.module('myUser', []);
app.controller('myCtrl', function($scope,$http) {
  //  $scope.RealName = "Michael"; 
  	$scope.toks = GetPermStorage("token");
	$scope.Tokenizer = "Token";
	$scope.space = " ";
	var data = $scope.Tokenizer+$scope.space+$scope.toks;
	console.log(data);
	/*$http.get('http://staging.tangent.tngnt.co/api/user/me/', {
    headers: {'Authorization': data}
});*/
//	$scope.data = {Token:$scope.toks}
	//$scope.tokk = "Token";
  //Call the services {headers: {'Authorization': $scope.tokk+$scope.data}}
$http.get('http://staging.tangent.tngnt.co/api/user/me/', {headers: {data}}).then(function (response) {
if (response.data)
$scope.info = "Successful login";
$scope.username = null;
$scope.password = null;
$scope.respData = response.data;
console.log($scope.respData);
//$scope._users = angular.fromJson(response.data);
//Processor($scope._users.token);
//PermStore("token",$scope._users.token);
 //$scope._users = response.data;
// $window.location.href = '../Tangent/pages/home.html';
//console.log($scope._users.token);
//$('#myGoodAlert').css("display","block");
}, function (response) {
$scope.statustext = "Service is missing";
/*
$scope.statusval = response.status;
$scope.statustext = response.statusText;
$scope.data = response.data;
$scope.headers = response.headers();*/
});

});


function GetPermStorage(myKey){
var getKey = localStorage.getItem(myKey);
return getKey;
}