function ShowReg(){	
$('#optLogin').css("display","none");
$('#optReg').css("display","block");
$('#myPass').css("display","none");
$('#myLogin').css("display","none");
$('#myRegister').css("display","block");
$('#passLink').css("display","block");
}

function ShowLog(){
$('#optLogin').css("display","block");
$('#optReg').css("display","none");
$('#myPass').css("display","none");
$('#myLogin').css("display","block");
$('#myRegister').css("display","none");
$('#passLink').css("display","block");	
}

function ShowPass(){
$('#myPass').css("display","block");
$('#optLogin').css("display","block");
$('#optReg').css("display","block");
$('#myLogin').css("display","none");
$('#passLink').css("display","none");
$('#myRegister').css("display","none");	
}

function RecS(data,status){
$('#loaderR').css("display","none");
if(data==='ED00UNF'){
$('#insPassErrorMsg').html("");
$('#insPassErrorMsg').html("<strong>Ouch! Your email is unknown to our system</strong>");
$('#myAlertPass').css("display","block");	
}
if(data==='ED00UEX'){
$('#insPassSucMsg').html("");
$('#insPassSucMsg').html("<strong>Awesome! Please check your inbox or spam folder</strong>");
$('#myGoodPass').css("display","block");
}
}

function RecF(data,status){
	$('#loaderR').css("display","none");
$('#insPassErrorMsg').html("");
$('#insPassErrorMsg').html("<strong>Ouch! Check your network</strong>");
$('#myAlertPass').css("display","block");	
}
function Recover(){
var userMail = $('#recmail').val();
var userLen = userMail.length;
if(userMail==='' || userLen<=5){
$('#insPassErrorMsg').html("");
$('#insPassErrorMsg').html("<strong>Please enter a valid email</strong>");
$('#myAlertPass').css("display","block");
}
else{
$('#myAlertPass').css("display","none");
$('#loaderR').css("display","block");
var funnel = "http://localhost/apps/EdokitaAdmin";//"https://mobilepushserver.com";
$.ajax({
type: 'POST',
url: funnel+'/api/recovery.php',
data: {eml:userMail},
success: RecS,
error : RecF,
cache:false,
async:true,
dataType: 'html'
});	
}
}

function LogS(data,status){
$('#loaderR').css("display","none");
//alert("data is "+data);	
$('#myemli').val('');
$('#mypwdi').val('');
if(data==='ED00UEX'){
window.location = "api/menu/home.php";
}
if(data==='ED00UNF'){
$('#insLogErrorMsg').html("");
$('#insLogErrorMsg').html("<strong>Oops! Wrong email or password</strong>");
$('#myAlertLog').css("display","block");
}
}
function LogF(data,status){
$('#loaderR').css("display","none");	
$('#insLogErrorMsg').html("");
$('#insLogErrorMsg').html("<strong>Ouch! Check your network</strong>");
$('#myAlertLog').css("display","block");	
}

var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope) {
    $scope.firstName= "";
    $scope.lastName= "";
	//$('#logbtn').click(function(){
	
	
});

function SignIn(){
	
	/*
var userMail = $('#myemli').val();
var usPass = $('#mypwdi').val();
var userLen = userMail.length;
if(userMail==='' ||  usPass===''){
$('#insLogErrorMsg').html("");
$('#insLogErrorMsg').html("<strong>Please enter a valid email</strong>");
$('#myAlertLog').css("display","block");
}
else{
$('#myAlertLog').css("display","none");
$('#loaderR').css("display","block");
var funnel = "http://localhost/apps/EdokitaAdmin";//"https://mobilepushserver.com";
$.ajax({
type: 'POST',
url: funnel+'/api/login.php',
data: {eml:userMail,ppw:usPass},
success: LogS,
error : LogF,
cache:false,
async:true,
dataType: 'html'
});	
}*/
}


function Register(){
$('#insErrorMsg').html("");	
var nom = $('#regname').val();	
var rml = $('#regmail').val();	
var crml = $('#confemail').val();	
var rpa = $('#regpass').val();	

if(nom===''){
$('#insErrorMsg').html("");
$('#insErrorMsg').html("<strong>Please enter your name</strong>");
$('#myAlert').css("display","block");
}
else{
$('#insErrorMsg').html("");
if(rml!==crml){
$('#insErrorMsg').html("<strong>Your confirmation email is different from the original one</strong>");
$('#myAlert').css("display","block");
}
if(rml===crml && rml.length<=5){
$('#insErrorMsg').html("<strong>Your email seems to be invalid!</strong>");
$('#myAlert').css("display","block");
if(rpa===''){
$('#insErrorMsg').html("<strong>Please enter your password</strong>");
$('#myAlert').css("display","block");
}
}
}
var curVal = $('#insErrorMsg').html();
if(curVal===''){
$('#myAlert').css("display","none");
$('#loaderR').css("display","block");
var funnel = "http://localhost/apps/EdokitaAdmin";//"https://mobilepushserver.com";
$.ajax({
type: 'POST',
url: funnel+'/api/joinme.php',
data: {usnam:nom,eml:crml,uspw:rpa},
success: JoinS,
error : JoinF,
cache:false,
async:true,
dataType: 'html'
});
}
}

function JoinF(data,status){
$('#loaderR').css("display","none");	
$('#insErrorMsg').html("<strong>Please check your network and try again!</strong>");
$('#myAlert').css("display","block");		
}
function JoinS(data,status){
$('#loaderR').css("display","none");
$('#regname').val('');	
$('#regmail').val('');	
$('#confemail').val('');	
$('#regpass').val('');
//alert("resp is "+data);	
if(data==='Forbidden'){
$('#insErrorMsgFooter').html("<strong>Forbidden</strong>");
$('#myAlertFooter').css("display","block");	
}
if(data==='ED00UEX'){
$('#insErrorMsg').html("<strong>User already exists</strong>");
$('#myAlert').css("display","block");
}
if(data==='ED11URE'){
$('#insErrorMsg').html("");
$('#myAlert').css("display","none");
$('#sucMsg').html("<strong>Successful Registration</strong>");
$('#myGoodAlert').css("display","block");
$('#optLogin').css("display","block");
$('#optReg').css("display","none");
$('#myPass').css("display","none");
$('#myLogin').css("display","block");
$('#myRegister').css("display","none");
$('#passLink').css("display","block");	
}
}
/*
$('#regname').click(function(){
$('#myAlert').alert('close');
});*/

$('#signLink').click(function(){
ShowReg();	
});
$('#signLinkId').click(function(){
ShowLog();	
});
$('#passLink').click(function(){
ShowPass();	
});
$('#signupbtn').click(function(){
Register();	
});

     
