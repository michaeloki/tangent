var app = angular.module('postService', ['ngRoute']);

// $location.path("home");
app.controller('postServiceCtrl', function ($scope, $http,$window) {
$scope.username = null;
$scope.password = null;
$scope.postdata = function (username, password) {
var data = {
username: username,
password: password
};
//Call the services
$http.post('http://staging.tangent.tngnt.co/api-token-auth/', data).then(function (response) {
if (response.data)
$scope.info = "Successful login";
$scope.username = null;
$scope.password = null;
//$scope.respData = response.data;
$scope._users = angular.fromJson(response.data);
//Processor($scope._users.token);
PermStore("token",$scope._users.token);
 //$scope._users = response.data;
 $window.location.href = '../Tangent/pages/homepage.html';
//console.log($scope._users.token);
$('#myGoodAlert').css("display","block");
}, function (response) {
$scope.statustext = "Service is missing";
/*
$scope.statusval = response.status;
$scope.statustext = response.statusText;
$scope.data = response.data;
$scope.headers = response.headers();*/
});
};
});




function PermStore(myKey,myVal){
localStorage.setItem(myKey,myVal);
}
function GetToken(){
    alert("loding..");
    var datax = {username:'pravin.gordhan',password:'pravin.gordhan'};
$.ajax({
contentType: 'application/json; charset=utf-8',
type: 'POST',	
url : 'http://staging.tangent.tngnt.co/api-token-auth/',
data: JSON.stringify(datax),
success: GetTokenSuc,
error:GetTokenFail,
async:true,
cache:false,
dataType:'html'
});
}
function GetTokenSuc(data,status){
alert(data);	
/*
var responseData = JSON.parse(data);
var user = responseData.username;
var pass = responseData.password;*/
	
}
function GetTokenFail(data,status){
    console.log(data);
//alert("data is "+data+"status "+status);
//var responseData = JSON.parse(data);
//a//lert(responseData);
}
