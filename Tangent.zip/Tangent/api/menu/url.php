<?php

$base_url = "http://localhost/apps/EdokitaAdmin/index.html";
?>
