function LogO(data,status){	
if(data==='DONE'){
window.location = "http://localhost/apps/EdokitaAdmin/index.html";
}	
}
function LogOF(data,status){
	
}
function Logout(){
var funnel = "http://localhost/apps/EdokitaAdmin";//"https://mobilepushserver.com";
$.ajax({
type: 'POST',
url: funnel+'/api/logout.php',
data: {},
success: LogO,
error : LogOF,
cache:false,
async:true,
dataType: 'html'
});
}

function AppStatusS(data,status){
alert(data);	
}
function AppStatusF(data,status){
	//alert(status+data);
data = data.split('#');
var us = data[0];
var cm = data[2];

$('#insLogErrorMsg').html("");
$('#insLogErrorMsg').html("<strong>Unable to fetch data!</strong>");
$('#myAlertLog').css("display","block");
$('#myGoodAlert').css("display","none");	
}
function AppStatus(){
var clientId = "UHY6tZ#@90&VfzPzm!RTfdvcYLPXcdHG";
var whoUser = $('#loggedUser').html();
var uri = "https://app.edokita.com/social";
$.ajax({
type: 'POST',
url: uri+'/services/appstatus.php',
data: {portKey:clientId},
success: AppStatusS,
error : AppStatusF,
cache:false,
async:true,
dataType: 'html'
});	
}

function SendPushS(data,status){
$('textarea#pushMsg').val("");
if(data==='done'){
$('#loaderR').css("display","none");	
$('#sucMsg').html("");
$('#sucMsg').html("<strong>Congratulations! Your messages has been sent.</strong>");
$('#myGoodAlert').css("display","block");
AuditTrail("push message");
}	
}
function SendPushF(data,status){
$('#insLogErrorMsg').html("");
$('#insLogErrorMsg').html("<strong>Unable to reach server!</strong>");
$('#myAlertLog').css("display","block");
$('#myGoodAlert').css("display","none");	
}

function AuditS(data,status){
if(data==='ILL000'){
$('#insLogErrorMsg').html("");
$('#insLogErrorMsg').html("<strong>ILLEGAL ACTIVITY HAS BEEN DETECTED !</strong>");
$('#myAlertLog').css("display","block");
$('#myGoodAlert').css("display","none");
Logout();	
}	
}
function AuditF(data,status){
	
}
function AuditTrail(reason){
var clientId = "UHY6tZ#@90&VfzPzm!RTfdvcYLPXcdHG";
var whoUser = $('#loggedUser').html();
var uri = "https://app.edokita.com/social";
$.ajax({
type: 'POST',
url: uri+'/services/audit.php',
data: {sender:whoUser,portKey:clientId,why:reason},
success: AuditS,
error : AuditF,
cache:false,
async:true,
dataType: 'html'
});
}
function SendPush(){
var msgCont = $('textarea#pushMsg').val();
if(msgCont===''){
$('#insLogErrorMsg').html("");
$('#insLogErrorMsg').html("<strong>Please enter your message !</strong>");
$('#myAlertLog').css("display","block");
$('#myGoodAlert').css("display","none");
}
else{
$('#loaderR').css("display","block");
var uri = "https://app.edokita.com/social";
$.ajax({
type: 'POST',
url: uri+'/services/process.php',
data: {pushname:'edok',message:msgCont},
success: SendPushS,
error : SendPushF,
cache:false,
async:true,
dataType: 'html'
});
}
}
function Push(){
$('#mainpush').css("display","block");
$('#mainpoll').css("display","none");
$('#mainchat').css("display","none");
$('#maindash').css("display","none");
}
function Polls(){
$('#mainpoll').css("display","block");
$('#mainpush').css("display","none");
$('#mainchat').css("display","none");
$('#maindash').css("display","none");
}
function Filter(){
$('#mainchat').css("display","block");
$('#mainpoll').css("display","none");
$('#maindash').css("display","none");
$('#mainpush').css("display","none");
}
function Home(){
$('#mainpush').css("display","none");
$('#mainpoll').css("display","none");
$('#mainchat').css("display","none");
$('#maindash').css("display","block");
}


function AddPollS(data,status){
if(data==='ADP11'){
$('#loaderR').css("display","none");	
$('#sucMsg').html("");
$('#sucMsg').html("<strong>Congratulations! Your poll has been created.</strong>");
$('#myGoodAlert').css("display","block");
$('#myAlertLog').css("display","none");
}
if(data==='ILL000'){
$('#insLogErrorMsg').html("");
$('#insLogErrorMsg').html("<strong>ILLEGAL ACTIVITY HAS BEEN DETECTED !</strong>");
$('#myAlertLog').css("display","block");
$('#myGoodAlert').css("display","block");
Logout();		
}
}
function AddPollF(data,status){
$('#insLogErrorMsg').html("");
$('#insLogErrorMsg').html("<strong>Unable to reach server!</strong>");
$('#myAlertLog').css("display","block");
$('#myGoodAlert').css("display","none");
}
function AddPoll(){
var ques = $('#pollque').val();
var answ = $('#pollans').val();
var op1 = $('#optOne').val();
var op2 = $('#optTwo').val();
var op3 = $('#optThree').val();
var op4 = $('#optFour').val();
var op5 = $('#optFive').val();
if(ques==='' || answ ==='' || op1===''||op2===''||op3===''||op4===''||op5===''){
$('#insLogErrorMsg').html("");
$('#insLogErrorMsg').html("<strong>All fields are required!</strong>");
$('#myAlertLog').css("display","block");
}
else{
var clientId = "UHY6tZ#@90&VfzPzm!RTfdvcYLPXcdHG";	
var whoUser = $('#loggedUser').html();
$('#loaderR').css("display","block");
var uri = "https://app.edokita.com/social";
$.ajax({
type: 'POST',
url: uri+'/services/addpoll.php',
data: {portKey:clientId,admin:whoUser,que:ques,ans:answ,op1:op1,op2:op2,op3:op3,op4:op4,op5:op5},
success: AddPollS,
error : AddPollF,
cache:false,
async:true,
dataType: 'html'
});	
}
}

function BlockF(data,status){
	
}
function BlockS(data,status){
	
}
function Block(){
$('textarea#blackMsg').val();
}