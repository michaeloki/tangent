<?php
date_default_timezone_set("Africa/Lagos");
include('url.php');
session_start();
$edload = $_SESSION["edokitaloader"];
if($edload=="loaded"){
require('dbcon.inc');
$usEm = $_POST['eml'];
$uspW = $_POST['ppw'];

//$myip = $_SERVER['REMOTE_ADDR'];
$encpass = base64_encode($uspW);

$daat = date ('y-m-d H:i:s');
  $dai = "20";
  $daati = $dai.$daat;
include('mydbcon.inc');
$exuser = "SELECT `namee` FROM `edoki127_mobAPPAdmin`.`edo_users` WHERE `email`='$usEm' AND `passKey`='$encpass'";
$stmti = $mydatcon->query($exuser);
$counci = $stmti ->rowCount();
if($counci==1){

if($row = $stmti->fetch(PDO::FETCH_ASSOC)) {
     $stna = $row['namee'];   
$_SESSION["userEmail"] = $usEm;
$_SESSION["userName"] = $stna;
$_SESSION["logout"] = "no";
	 if($stna!=''){
	 echo "ED00UEX";
	 $mydatcon = null;
	 include('mydbcon.inc');
	 $upUserLog = "UPDATE `edoki127_mobAPPAdmin`.`edo_users` SET `lgDat`='$daati' WHERE `email`='$usEm'";
	 $stmtu = $mydatcon->query($upUserLog);
	  $mydatcon = null;
	 }
	 /*
//echo "$past";
$subject = 'EdokitaMobile Admin Password Recovery';
$message = '<div style="background:#f5f5f5;"><img src="https://app.edokita.com/social/elogo3.png" width="100" height="100" style="float:right;">
<br>Dear '.$stna.',<br><br>
Your password is: '.$past.'<br><br>
<br><br>
We are glad to have you!
';
$headers = 'From: Edokita App <admin@edokita.com>' . "\r\n".
       'Content-type: text/html; charset=utf-8' . "\r\n";
mail($usEm, $subject, $message, $headers);*/	
}
}
else{
echo "ED00UNF";//NOT FOUND
}	
}
else{
//echo "Forbidden";
header("Location: $base_url");
die();
}
?>