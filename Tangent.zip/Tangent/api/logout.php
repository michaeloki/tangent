<?php 
session_start();
$_SESSION["userEmail"] = "";
$_SESSION["userName"] = "";
$_SESSION["logout"] = "yes";
//session_destroy();
//header("Location: http://localhost/apps/EdokitaAdmin/index.html");
echo "DONE";
?>