<?php
date_default_timezone_set("Africa/Lagos");
include('url.php');
session_start();
//$req = $_SERVER['REQUEST_URI'];
//echo "$req";
$edload = $_SESSION["edokitaloader"];
if($edload=="loaded"){
require('dbcon.inc');
$usName = $_POST['usnam'];
$usEm = $_POST['eml'];
$uspW = $_POST['uspw'];
$myip = $_SERVER['REMOTE_ADDR'];
$encpass = base64_encode($uspW);
//$usMail = $_POST[''];
$mqrry = "SELECT `id` FROM `edoki127_mobAPPAdmin`.`whitelistuser` WHERE `email`='$usEm' ";
$stmt = $datcon->query($mqrry);
$counc = $stmt ->rowCount();
$daat = date ('y-m-d H:i:s');
  $dai = "20";
  $daati = $dai.$daat;
if($counc==1){
//echo "found";	
//chk user existence then insert
$datcon = null;
include('mydbcon.inc');
$exuser = "SELECT `id` FROM `edoki127_mobAPPAdmin`.`edo_users` WHERE `email`='$usEm' ";
$stmti = $mydatcon->query($exuser);
$counci = $stmti ->rowCount();
if($counci==1){
echo "ED00UEX";//USER EXISTS	
}
else{
$mydatcon = null;
require('dbcon.inc');
$insq = "INSERT INTO `edoki127_mobAPPAdmin`.`edo_users` (namee,email,passKey,regDat,lgDat,ip,logOut) VALUES ('$usName','$usEm','$encpass','$daati','nil','$myip','nil')";
$onboard = $datcon->exec($insq);
$insertId = $datcon->lastInsertId();
echo "ED11URE";//REGD
}
}
}
else{
//echo "Forbidden";
header("Location: $base_url");
die();
}
?>